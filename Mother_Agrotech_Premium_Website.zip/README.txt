MOTHER AGROTECH PREMIUM WEBSITE

1. Keep index.html and logo.jpg in the same folder.
2. Open index.html to preview the website.
3. Upload both files to your hosting/server public folder.

Included:
- Premium responsive Home page
- About section
- Groundnut trading
- Seed varieties: Mother Raja, Mother Profit, Mother Lakshmi
- Why Us
- Contact / Call / WhatsApp buttons
- Your supplied logo
- Mobile-friendly design
